import os
import streamlit as st
import google.generativeai as genai
from dotenv import load_dotenv

load_dotenv()
API_KEY = os.getenv("GEMINI_API_KEY")
genai.configure(api_key=API_KEY)

model = genai.GenerativeModel("gemini-pro")

st.title("🌍 Language Translator Chatbot")

text = st.text_area("Enter text to translate")
target_lang = st.selectbox("Translate to:", ["Urdu", "Hindi", "French", "Arabic", "Chinese", "Spanish"])

if st.button("Translate"):
    prompt = f"Translate the following text to {target_lang}:
{text}"
    try:
        response = model.generate_content(prompt)
        st.success("Translation:")
        st.write(response.text)
    except Exception as e:
        st.error(f"Translation failed: {e}")