# Language Translator Chatbot

A simple chatbot using Gemini API and Streamlit for language translation.